﻿using CodeBlacks.Services;
using Microsoft.ServiceFabric.Services.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Fabric;
using Microsoft.ServiceFabric.Services.Communication.Runtime;
using Microsoft.ServiceFabric.Services.Remoting.Runtime;

namespace CodeBlacks.BackEnd.Services
{
    public sealed class CharityService : StatelessService, ICharityService
    {
        public CharityService(StatelessServiceContext serviceContext) : base(serviceContext)
        {
        }

        public Task<List<Charity>> GetCharities(string country)
        {
            return Task.FromResult(Impact.GetCharitiesInCountry(country));
        }

        public Task<List<DonationImpact>> GetDonationImpact(string country, string charity, decimal amount)
        {
            return Task.FromResult(Impact.GetDonationImpact(country, charity, (double)amount));
        }

        protected override IEnumerable<ServiceInstanceListener> CreateServiceInstanceListeners()
        {
            return new[] { new ServiceInstanceListener(context => this.CreateServiceRemotingListener(context)) };
        }

    }
}

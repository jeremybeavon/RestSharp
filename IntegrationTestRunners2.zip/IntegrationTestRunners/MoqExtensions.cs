﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Reflection;
using Moq;
using Moq.Language;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public static class MoqExtensions
	{
		private static readonly IDictionary<ReturnsKey, ReturnsFunc> returnValueFunctions = new Dictionary<ReturnsKey, ReturnsFunc>();
		private static readonly Action<ICallback, Delegate> callbackFunc = ((Func<Action<ICallback, Delegate>>)(() =>
		{
			ParameterExpression callbackParameter = Expression.Parameter(typeof(ICallback));
			ParameterExpression delegateParameter = Expression.Parameter(typeof(Delegate));
			Type type = typeof(Mock<>).Assembly.GetType("Moq.MethodCall");
			Expression call = Expression.Call(
				Expression.Convert(callbackParameter, type),
				type.GetMethod("SetCallbackWithArguments", BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance),
				new Expression[] { delegateParameter });
			return Expression.Lambda<Action<ICallback, Delegate>>(
				call,
				callbackParameter,
				delegateParameter).Compile();
		}))();

		private delegate void ReturnsFunc(object setup, Delegate returnValueDelegate);

		public static void Callback(this ICallback callback, Delegate action)
		{
			callbackFunc(callback, action);
		}

		public static void Returns<TMock, TResult>(this IReturns<TMock, TResult> returns, Delegate returnValueDelegate)
			where TMock : class
		{
			var functionKey = new ReturnsKey(typeof(TMock), typeof(TResult));
			ReturnsFunc returnValueFunc;
			if (!returnValueFunctions.TryGetValue(functionKey, out returnValueFunc))
			{
				ParameterExpression setupParameter = Expression.Parameter(typeof(object));
				ParameterExpression returnValueDelegateParameter = Expression.Parameter(typeof(Delegate));
				Type type = returns.GetType();
				MethodInfo methodToCall = type.GetMethod("SetReturnDelegate", BindingFlags.NonPublic | BindingFlags.Instance);
				Expression call = Expression.Call(
					Expression.Convert(setupParameter, type),
					methodToCall,
					new Expression[] { returnValueDelegateParameter });
				returnValueFunc = Expression.Lambda<ReturnsFunc>(
					call,
					setupParameter,
					returnValueDelegateParameter).Compile();
				returnValueFunctions.Add(functionKey, returnValueFunc);
			}

			returnValueFunc(returns, returnValueDelegate);
		}

		private sealed class ReturnsKey : IEquatable<ReturnsKey>
		{
			private readonly Tuple<Type, Type> tuple;

			public ReturnsKey(Type mockType, Type resultType)
			{
				tuple = new Tuple<Type, Type>(mockType, resultType);
			}

			public bool Equals(ReturnsKey other)
			{
				return other != null && tuple.Equals(other.tuple);
			}

			public override bool Equals(object obj)
			{
				return Equals(obj as ReturnsKey);
			}

			public override int GetHashCode()
			{
				return tuple.GetHashCode();
			}
		}
	}
}

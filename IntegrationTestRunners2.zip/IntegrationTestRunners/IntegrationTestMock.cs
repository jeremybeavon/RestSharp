﻿using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class IntegrationTestMock<T>
	{
		//public abstract void VerifyAll(IList<string> methodCallCountFailures);

		public virtual void AttachPassThroughObject(T instance)
		{
		}
	}
}

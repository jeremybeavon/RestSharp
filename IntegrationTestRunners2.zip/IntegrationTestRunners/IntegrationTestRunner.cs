﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;
using Microsoft.CSharp;
using NUnit.Framework;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class IntegrationTestRunner
	{
		private static readonly string assemblyDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		private static readonly string testsFolder = Path.GetFullPath(Path.Combine(assemblyDirectory, @"..\..\.."));
		private static readonly string integrationTestsBinFolder = Path.Combine(testsFolder, @"IntegrationTests\bin\Debug");
		private static readonly Assembly unitTestsAssembly = typeof(IntegrationTestRunner).Assembly;
		private static readonly Assembly integrationTestsAssembly = Assembly.LoadFrom(Path.Combine(integrationTestsBinFolder, "Ax.IntegrationTests.dll"));
		private readonly ParallelTestRunner<RemoteIntegrationTestRunner, RemoteIntegrationTest> testRunner;
		private readonly IntegrationTestBuilder testBuilder;
		private readonly RemoteIntegrationTestRunner remoteTestRunner;
		private readonly HashSet<string> methodsToRunInParallel;
		private MocksAssemblyLoader mocksAssembly;
		private bool doesMockIncludeDataAccess;

		public IntegrationTestRunner()
		{
			testRunner = new ParallelTestRunner<RemoteIntegrationTestRunner, RemoteIntegrationTest>();
			testBuilder = new IntegrationTestBuilder(this);
			remoteTestRunner = new RemoteIntegrationTestRunner();
			methodsToRunInParallel = new HashSet<string>();
		}

		public void TestFixtureSetUp(bool includeDataAccess, IEnumerable<string> methods)
		{
			doesMockIncludeDataAccess = includeDataAccess;
			BuildMocksAssembly(GetSourceDirectory(includeDataAccess));
			if (mocksAssembly == null)
			{
				return;
			}

			IDictionary<string, string> methodNames = methods.ToDictionary(name => GetMockTypeName(name, includeDataAccess));
			var typeNames = new HashSet<string>(mocksAssembly.PublicTypes);
			foreach (KeyValuePair<string, string> methodName in methodNames)
			{
				if (typeNames.Contains(methodName.Key))
				{
					methodsToRunInParallel.Add(methodName.Value);
					typeNames.Remove(methodName.Key);
				}
			}

			foreach (string unusedTypeName in typeNames)
			{
				File.Delete(IntegrationTestBuilder.GetFileName(unusedTypeName));
			}

			testRunner.TestFixtureSetUp(
				methodsToRunInParallel.Select(method => new RemoteIntegrationTest(method, mocksAssembly, includeDataAccess)));
		}

		public void TestFixtureTearDown()
		{
			testRunner.TestFixtureTearDown();
			if (mocksAssembly != null)
			{
				mocksAssembly.Unload();
			}
		}

		public void RunIntegrationTest(string method)
		{
			if (methodsToRunInParallel.Contains(method))
			{
				TestResult testResult = testRunner.RunTest(
					new RemoteIntegrationTest(method, mocksAssembly, doesMockIncludeDataAccess));
				if (testResult.TestException != null ||
				    testResult.TearDownException != null ||
				    testResult.TestFixtureTearDownException != null)
				{
					testBuilder.RunIntegrationTest(method);
				}
			}
			else
			{
				testBuilder.RunIntegrationTest(method);
			}
		}

		public TestResult RunLocalIntegrationTest(string method)
		{
			return remoteTestRunner.RunIntegrationTest(method);
		}

		public MethodInfo GetTestMethod(string testName)
		{
			return remoteTestRunner.GetTestMethod(testName);
		}

		private static string[] GetReferencedAssemblies(ICollection<Assembly> assemblies)
		{
			ResolveEventHandler resolveHandler = (sender, args) =>
			{
				string assemblyName = new AssemblyName(args.Name).Name;
				string fileName = Path.Combine(integrationTestsBinFolder, assemblyName + ".dll");
				if (!File.Exists(fileName))
				{
					fileName = Path.Combine(integrationTestsBinFolder, assemblyName + ".exe");
				}

				return File.Exists(fileName) ? Assembly.LoadFrom(fileName) : null;
			};
			AppDomain.CurrentDomain.AssemblyResolve += resolveHandler;
			var referencedAssemblies = new HashSet<Assembly>(assemblies);
			BuildAssemblyList(assemblies, referencedAssemblies);
			string[] referencedAssemblyPaths = referencedAssemblies
				.OrderBy(assembly => Path.GetFileName(assembly.Location))
				.Select(assembly => assembly.Location)
				.ToArray();
			AppDomain.CurrentDomain.AssemblyResolve -= resolveHandler;
			return referencedAssemblyPaths;
		}

		private static void BuildAssemblyList(IEnumerable<Assembly> assemblies, ISet<Assembly> referencedAssemblies)
		{
			Assembly[] newAssemblies = assemblies
				.Where(assembly => !assembly.GlobalAssemblyCache)
				.SelectMany(assembly => assembly.GetReferencedAssemblies().Select(Assembly.Load))
				.Where(referencedAssemblies.Add)
				.ToArray();
			if (newAssemblies.Length != 0)
			{
				BuildAssemblyList(newAssemblies, referencedAssemblies);
			}
		}

		private static string GetSourceDirectory(bool includeDataAccess)
		{
			return includeDataAccess ?
				IntegrationTestBuilder.MocksWithDataAccessSourceDirectory :
				IntegrationTestBuilder.MocksWithoutDataAccessSourceDirectory;
		}

		private static string GetMockTypeName(string method, bool includeDataAccess)
		{
			var name = new IntegrationTestName(method);
			return IntegrationTestBuilder.GetTypeName(name.TestClassName, name.TestMethodName, includeDataAccess);
		}

		private static IEnumerable<string> GetTests(params string[] testClassNames)
		{
			return testClassNames.SelectMany(className => GetTests(GetType(className)));
		}

		private static Type GetType(string typeName)
		{
			return integrationTestsAssembly.GetType(typeName, true);
		}

		private static bool IsTestMethod(MethodInfo method)
		{
			return Attribute.IsDefined(method, typeof(TestAttribute)) &&
			       !Attribute.IsDefined(method, typeof(IgnoreAttribute));
		}

		private static IEnumerable<string> GetTests(Type type)
		{
			return type.GetMethods()
				.Where(IsTestMethod)
				.OrderBy(method => method.Name)
				.Select(method => string.Format("{0}::{1}", type.FullName, method.Name));
		}

		private void BuildMocksAssembly(string sourceDirectory)
		{
			string directory = Path.Combine(assemblyDirectory, "MocksAssembly", Guid.NewGuid().ToString("N"));
			Directory.CreateDirectory(directory);
			var parameters = new CompilerParameters
			{
				IncludeDebugInformation = true,
				CompilerOptions = string.Format("/keyfile:\"{0}\"", Path.GetFullPath(Path.Combine(testsFolder, @"..\_Shared\keypair.snk"))),
				OutputAssembly = Path.Combine(directory, @"Ax.UnitTests.dll")
			};
			parameters.ReferencedAssemblies.AddRange(GetReferencedAssemblies(new[] { unitTestsAssembly, integrationTestsAssembly }));
			Directory.CreateDirectory(sourceDirectory);
			string[] sourceFiles = Directory.GetFiles(sourceDirectory, "*.cs", SearchOption.AllDirectories);
			if (sourceFiles.Length == 0)
			{
				return;
			}

			BuildMocksAssembly(sourceFiles, parameters);
		}

		private void BuildMocksAssembly(string[] sourceFiles, CompilerParameters parameters)
		{
			var codeCompiler = new CSharpCodeProvider();
			CompilerResults results = codeCompiler.CompileAssemblyFromFile(parameters, sourceFiles);
			if (results.Errors.Count != 0)
			{
				sourceFiles = sourceFiles.Except(results.Errors.Cast<CompilerError>().Select(error => error.FileName).Distinct()).ToArray();
				if (sourceFiles.Length == 0)
				{
					return;
				}

				results = codeCompiler.CompileAssemblyFromFile(parameters, sourceFiles);
				if (results.Errors.Count != 0)
				{
					throw new InvalidOperationException();
				}
			}

			mocksAssembly = new MocksAssemblyLoader(parameters.OutputAssembly);
		}

		private sealed class IntegrationTestName
		{
			public IntegrationTestName(string testName)
			{
				string[] testParts = testName.Split(new[] { "::" }, StringSplitOptions.None);
				TestClassName = testParts[0];
				TestMethodName = testParts[1];
			}

			public string TestClassName { get; private set; }

			public string TestMethodName { get; private set; }
		}

		private sealed class MocksAssemblyLoader : MarshalByRefObject
		{
			private readonly string assemblyFile;

			public MocksAssemblyLoader(string assemblyFile)
			{
				this.assemblyFile = assemblyFile;
			}

			public IEnumerable<string> PublicTypes
			{
				get { return Assembly.Load(File.ReadAllBytes(assemblyFile)).GetTypes().Where(type => type.IsPublic).Select(type => type.FullName); }
			}

			private string AssemblyFile
			{
				get { return assemblyFile; }
			}

			public static Assembly Load(MocksAssemblyLoader assembly)
			{
				return Assembly.LoadFrom(assembly.AssemblyFile);
			}

			public override object InitializeLifetimeService()
			{
				return null;
			}

			public void Unload()
			{
				string directory = Path.GetDirectoryName(assemblyFile);
				if (directory != null)
				{
					Directory.Delete(directory, true);
				}
			}
		}

		[Serializable]
		private sealed class RemoteIntegrationTest : RemoteTestParameter
		{
			private RemoteIntegrationTest()
			{
			}

			public RemoteIntegrationTest(string testName, MocksAssemblyLoader mocksAssembly, bool includeDataAccess)
				: base(testName)
			{
				MocksAssembly = mocksAssembly;
				IncludeDataAccess = includeDataAccess;
			}

			public MocksAssemblyLoader MocksAssembly { get; private set; }

			public bool IncludeDataAccess { get; private set; }
		}

		private sealed class RemoteIntegrationTestRunner : RemoteTestRunner<RemoteIntegrationTest>
		{
			private readonly IDictionary<Type, IntegrationTestClass> testClasses;
			private string currentDirectory;
			private Assembly mocksAssembly;

			public RemoteIntegrationTestRunner()
			{
				testClasses = new Dictionary<Type, IntegrationTestClass>();
			}

			public override TestResult RunTest(RemoteIntegrationTest parameter)
			{
				var integrationTestName = new IntegrationTestName(parameter.TestName);
				string mockTestTypeName = IntegrationTestBuilder.GetTypeName(
					integrationTestName.TestClassName,
					integrationTestName.TestMethodName,
					parameter.IncludeDataAccess);
				if (mocksAssembly == null)
				{
					mocksAssembly = MocksAssemblyLoader.Load(parameter.MocksAssembly);
				}

				var mockTest = (IntegrationMockTest)Activator.CreateInstance(mocksAssembly.GetType(mockTestTypeName));
				mockTest.SetUp();
				TestResult result = RunIntegrationTest(integrationTestName);
				try
				{
					mockTest.TearDown();
				}
				catch (Exception exception)
				{
					result.TearDownException = result.TearDownException == null ?
						exception :
						new AggregateException(result.TearDownException, exception);
				}

				return result;
			}

			public TestResult RunIntegrationTest(string testName)
			{
				return RunIntegrationTest(new IntegrationTestName(testName));
			}

			public MethodInfo GetTestMethod(string testName)
			{
				var integrationTestName = new IntegrationTestName(testName);
				return GetIntegrationTestClass(IntegrationTestRunner.GetType(integrationTestName.TestClassName))
					.GetTestMethod(integrationTestName.TestMethodName);
			}

			private TestResult RunIntegrationTest(IntegrationTestName testName)
			{
				currentDirectory = Environment.CurrentDirectory;
				Environment.CurrentDirectory = integrationTestsBinFolder;
				try
				{
					return GetIntegrationTestClass(IntegrationTestRunner.GetType(testName.TestClassName))
						.RunTest(testName.TestMethodName);
				}
				finally
				{
					Environment.CurrentDirectory = currentDirectory;
				}
			}

			private IntegrationTestClass GetIntegrationTestClass(Type type)
			{
				IntegrationTestClass testClass;
				if (!testClasses.TryGetValue(type, out testClass))
				{
					testClass = new IntegrationTestClass(type);
					testClasses.Add(type, testClass);
				}

				return testClass;
			}

			private sealed class IntegrationTestClass
			{
				private readonly Type type;
				private readonly Func<object> factory;
				private readonly IDictionary<string, MethodInfo> testMethods;

				public IntegrationTestClass(Type type)
				{
					this.type = type;
					factory = Expression.Lambda<Func<object>>(Expression.New(type)).Compile();
					MethodInfo[] methods = type.GetMethods();
					testMethods = methods.Where(IsTestMethod).ToDictionary(method => method.Name);
					TestFixtureSetUp = CreateActionIfNecessary(methods, typeof(TestFixtureSetUpAttribute));
					SetUp = CreateActionIfNecessary(methods, typeof(SetUpAttribute));
					TearDown = CreateActionIfNecessary(methods, typeof(TearDownAttribute));
					TextFixtureTearDown = CreateActionIfNecessary(methods, typeof(TestFixtureTearDownAttribute));
				}

				public Action<object> TestFixtureSetUp { get; private set; }

				public Action<object> SetUp { get; private set; }

				public Action<object> TearDown { get; private set; }

				public Action<object> TextFixtureTearDown { get; private set; }

				public MethodInfo GetTestMethod(string methodName)
				{
					return testMethods[methodName];
				}

				public TestResult RunTest(string methodName)
				{
					return new IntegrationTest(this, factory(), testMethods[methodName]).RunTest();
				}

				private Action<object> CreateActionIfNecessary(IEnumerable<MethodInfo> methods, Type attributeType)
				{
					MethodInfo method = methods.FirstOrDefault(test => Attribute.IsDefined(test, attributeType));
					if (method != null)
					{
						ParameterExpression parameter = Expression.Parameter(typeof(object));
						return Expression.Lambda<Action<object>>(
							Expression.Call(Expression.Convert(parameter, type), method),
							parameter).Compile();
					}

					return null;
				}
			}

			private sealed class IntegrationTest
			{
				private readonly IntegrationTestClass integrationTestClass;
				private readonly object integrationTestInstance;
				private readonly MethodInfo testMethod;

				public IntegrationTest(IntegrationTestClass integrationTestClass, object integrationTestInstance, MethodInfo testMethod)
				{
					this.integrationTestClass = integrationTestClass;
					this.integrationTestInstance = integrationTestInstance;
					this.testMethod = testMethod;
				}

				public TestResult RunTest()
				{
					var testResult = new TestResult();
					try
					{
						RunIfNotNull(integrationTestClass.TestFixtureSetUp);
						RunTest(testResult);
					}
					catch (Exception exception)
					{
						testResult.TestException = exception;
					}
					finally
					{
						try
						{
							RunIfNotNull(integrationTestClass.TextFixtureTearDown);
						}
						catch (Exception exception)
						{
							testResult.TestFixtureTearDownException = exception;
						}
					}
					
					return testResult;
				}

				private void RunTest(TestResult testResult)
				{
					try
					{
						RunIfNotNull(integrationTestClass.SetUp);
						testMethod.Invoke(integrationTestInstance, new object[0]);
					}
					finally
					{
						try
						{
							RunIfNotNull(integrationTestClass.TearDown);
						}
						catch (Exception exception)
						{
							testResult.TearDownException = exception;
						}
					}
				}

				private void RunIfNotNull(Action<object> action)
				{
					if (action != null)
					{
						action(integrationTestInstance);
					}
				}
			}
		}
	}
}
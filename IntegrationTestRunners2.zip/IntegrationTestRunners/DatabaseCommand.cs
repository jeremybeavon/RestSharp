﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Text;
using DbCommandType = System.Data.CommandType;

namespace Ax.UnitTests.IntegrationTestRunners
{
    internal sealed class DatabaseCommand : DbCommand
    {
        private readonly DbParameterCollection parameters;

        internal DatabaseCommand()
        {
            parameters = new DatabaseParameterCollection();
        }

        public override void Cancel()
        {
        }

        public override string CommandText { get; set; }

        public override int CommandTimeout { get; set; }

        public override DbCommandType CommandType { get; set; }

        protected override DbParameter CreateDbParameter()
        {
            return new DatabaseParameter();
        }

        protected override DbConnection DbConnection { get; set; }

        protected override DbParameterCollection DbParameterCollection 
        {
            get { return parameters; }
        }

        protected override DbTransaction DbTransaction { get; set; }

        public override bool DesignTimeVisible { get; set; }

        public override UpdateRowSource UpdatedRowSource { get; set; }

        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
        {
            return ExecuteCommand(database.ExecuteReader);
        }

        public override int ExecuteNonQuery()
        {
            return ExecuteCommand(database.ExecuteNonQuery);
        }

        public override object ExecuteScalar()
        {
            return ExecuteCommand(database.ExecuteScalar);
        }

        public override void Prepare()
        {
        }

        private T ExecuteCommand<T>(ExecuteCommandFunc<T> executeCommandFunc)
        {
            StringBuilder parameterText = new StringBuilder();
            IList<Variable> variables = new List<Variable>();
            ProcessParameters(parameterText, variables);
            string commandText = CommandType == CommandType.StoredProcedure ?
                string.Format("EXECUTE {0} {1}", CommandText, parameterText.ToString()) :
                CommandText;
            return executeCommandFunc(commandText, variables);
        }

        private void ProcessParameters(StringBuilder parameterText, IList<Variable> variables)
        {
            int unnamedParameterCount = 0;
            string commaText = string.Empty;
            foreach (DbParameter parameter in Parameters)
            {
                parameterText.Append(commaText);
                commaText = ", ";
                string parameterName;
                if (string.IsNullOrWhiteSpace(parameter.ParameterName))
                {
                    unnamedParameterCount++;
                    parameterName = string.Concat("@UnnamedParameter", unnamedParameterCount);
                }
                else
                {
                    parameterName = parameter.ParameterName;
                    if (!parameterName.StartsWith("@"))
                    {
                        parameterName = "@" + parameterName;
                    }

                    parameterText.Append(parameterName);
                    parameterText.Append(" = ");
                }

                parameterText.Append(parameterName);
                Variable variable = new Variable(
                    parameterName,
                    parameter.Value == null ? typeof(object) : parameter.Value.GetType(),
                    parameter.Value);
                variables.Add(variable);
            }
        }
    }
}

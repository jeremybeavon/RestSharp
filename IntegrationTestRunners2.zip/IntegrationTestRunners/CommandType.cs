﻿namespace Ax.UnitTests.IntegrationTestRunners
{
	public enum CommandType
	{
		Scalar,
		NonQuery,
		Reader
	}
}

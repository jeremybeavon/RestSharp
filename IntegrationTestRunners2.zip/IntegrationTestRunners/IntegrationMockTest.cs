﻿using Ax.Frameworks.SysUtils;
using Ax.TestingCommon.UnitTests;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class IntegrationMockTest
	{
		private IUnitTestServiceInstanceProvider instanceProvider;

		public virtual void SetUp()
		{
			instanceProvider = CreateServiceInstanceProvider();
			ServiceFactory.ServiceInstanceProvider = instanceProvider;
		}

		public virtual void TearDown()
		{
			ServiceFactory.ServiceInstanceProvider = null;
		}

		protected abstract IUnitTestServiceInstanceProvider CreateServiceInstanceProvider();

		protected void Register<TService>(TService implementation)
		{
			instanceProvider.Register(implementation);
		}
	}
}

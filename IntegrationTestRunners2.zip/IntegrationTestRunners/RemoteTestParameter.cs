﻿using System;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[Serializable]
	public class RemoteTestParameter //: MarshalByRefObject
	{
		public RemoteTestParameter()
		{
		}

		public RemoteTestParameter(string testName)
		{
			TestName = testName;
		}

		public string TestName { get; private set; }

		/*public sealed override object InitializeLifetimeService()
		{
			return null;
		}*/
	}
}

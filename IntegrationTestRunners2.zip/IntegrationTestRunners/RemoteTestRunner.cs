﻿using System;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class RemoteTestRunner<TRemoteTestParameter> : MarshalByRefObject
		where TRemoteTestParameter : RemoteTestParameter
	{
		public abstract TestResult RunTest(TRemoteTestParameter parameter);

		public sealed override object InitializeLifetimeService()
		{
			return null;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Runtime.Remoting;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Proxies;
using Ax.Frameworks.BOF;
using Ax.TestingCommon.UnitTests;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class IntegrationTestServiceInstanceProvider : IUnitTestServiceInstanceProvider
	{
		private readonly Dictionary<Type, object> dictionary = new Dictionary<Type, object>();
		private readonly HashSet<Type> passThroughTypes;

		public IntegrationTestServiceInstanceProvider(params Type[] passThroughTypes)
		{
			dictionary = new Dictionary<Type, object>();
			this.passThroughTypes = new HashSet<Type>(passThroughTypes);
		}

		public T Resolve<T>(Func<T> constructor)
			where T : class
		{
			object resolvedObject;
			if (!dictionary.TryGetValue(typeof(T), out resolvedObject))
			{
				resolvedObject = passThroughTypes.Contains(typeof(T)) ?
					constructor() :
					new EmptyProxy(typeof(T)).GetTransparentProxy();
				dictionary.Add(typeof(T), resolvedObject);
			}

			return (T)resolvedObject;
		}

		public void Register<TService>(TService implementation)
		{
			dictionary.Add(typeof(TService), implementation);
			if (typeof(TService) == typeof(IContextInternal))
			{
				dictionary.Add(typeof(IContext), (IContext)implementation);
			}
		}

		public bool DiagnoseMockCreation
		{
			get { return false; }
			set { }
		}

		private sealed class EmptyProxy : RealProxy, IRemotingTypeInfo
		{
			private readonly Type type;

			public EmptyProxy(Type type)
				: base(typeof(ContextBoundObject))
			{
				this.type = type;
			}

			public string TypeName
			{
				get { return GetType().Name; }
				set { }
			}

			public bool CanCastTo(Type fromType, object o)
			{
				return fromType == type;
			}

			public override IMessage Invoke(IMessage msg)
			{
				var message = msg as IMethodCallMessage;
				if (message == null)
				{
					throw new NotSupportedException();
				}

				if (message.MethodBase.DeclaringType == typeof(object))
				{
					return CreateReturnMessage(
						message,
						message.MethodBase.Name == "GetType" ? type : message.MethodBase.Invoke(this, message.Args));
				}

				throw new UnexpectedCallException();
			}

			private static IMethodReturnMessage CreateReturnMessage(IMethodCallMessage message, object returnValue)
			{
				return new ReturnMessage(returnValue, null, 0, message.LogicalCallContext, message);
			}
		}
	}
}

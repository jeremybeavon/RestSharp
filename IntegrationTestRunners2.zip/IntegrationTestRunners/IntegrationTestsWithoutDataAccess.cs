﻿using System.Collections.Generic;
using NUnit.Framework;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[TestFixture]
	public sealed class IntegrationTestsWithoutDataAccess
	{
		private static readonly IEnumerable<string> integrationTests = new[]
		{
			"Ax.IntegrationTests.Contract.MortgageTest::CalculateRepayments"
		};

		private readonly IntegrationTestRunner testRunner;

		public IntegrationTestsWithoutDataAccess()
		{
			testRunner = new IntegrationTestRunner();
		}

		[TestFixtureSetUp]
		public void SetUp()
		{
			testRunner.TestFixtureSetUp(true, integrationTests);
		}

		[TestFixtureTearDown]
		public void TearDown()
		{
			testRunner.TestFixtureTearDown();
		}

		[Test]
		[TestCaseSource("integrationTests")]
		public void RunIntegrationTest(string testName)
		{
			testRunner.RunIntegrationTest(testName);
		}
	}
}

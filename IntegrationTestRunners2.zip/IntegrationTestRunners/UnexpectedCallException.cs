﻿using System;
using System.Runtime.Serialization;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[Serializable]
	public class UnexpectedCallException : Exception
	{
		public UnexpectedCallException()
		{
		}

		protected UnexpectedCallException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}
	}
}

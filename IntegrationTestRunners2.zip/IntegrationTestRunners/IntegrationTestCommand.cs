﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class IntegrationTestCommand
	{
		public string CommandText { get; set; }

		public object Parameters { get; set; }



		public object Result { get; set; }
	}
}

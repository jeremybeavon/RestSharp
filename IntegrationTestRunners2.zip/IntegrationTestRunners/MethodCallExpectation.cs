﻿using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public class MethodCallExpectation
	{
		private readonly string methodDescription;
		private readonly int expectedCallCount;
		private int callCount;

		public MethodCallExpectation(string methodDescription, int expectedCallCount)
		{
			this.methodDescription = methodDescription;
			this.expectedCallCount = expectedCallCount;
		}

		public void RegisterCall()
		{
			callCount++;
		}

		public void Verify(IList<string> uncalledMethods)
		{
			if (callCount != expectedCallCount)
			{
				uncalledMethods.Add(methodDescription);
			}
		}
	}
}

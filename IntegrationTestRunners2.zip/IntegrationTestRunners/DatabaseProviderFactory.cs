﻿using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace DatabaseEngine
{
    public sealed class DatabaseProviderFactory : DbProviderFactory
    {
        private readonly Database database;

        public DatabaseProviderFactory(string databaseDirectory, IEnumerable<IDatabaseFile> databaseFiles)
        {
            database = new Database(databaseDirectory, databaseFiles);
        }

        public DatabaseProviderFactory(string databaseDirectory, params IDatabaseFile[] databaseFiles)
        {
            database = new Database(databaseDirectory, databaseFiles);
        }

        public override DbConnection CreateConnection()
        {
            return new DatabaseConnection(database);
        }

        public override DbCommand CreateCommand()
        {
            return new DatabaseCommand(database);
        }

        public override DbParameter CreateParameter()
        {
            return new DatabaseParameter();
        }

        public override DbDataAdapter CreateDataAdapter()
        {
            return new DatabaseDataAdapter();
        }

	    public void DeriveParameters(IDbCommand command)
	    {
		    foreach (Parameter parameter in database.StoredProcedures.Contains(command.CommandText) ?
				database.StoredProcedures[command.CommandText].Parameters :
				database.Functions[command.CommandText].Parameters)
		    {
			    IDbDataParameter dbParameter = command.CreateParameter();
			    dbParameter.ParameterName = parameter.Name;
			    dbParameter.Value = parameter.DefaultValue;
			    command.Parameters.Add(dbParameter);
		    }
	    }
    }
}

﻿using System.Data;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    internal sealed class DatabaseTransaction : DbTransaction
    {
        private readonly DatabaseConnection connection;
	    private readonly IsolationLevel isolationLevel;

        public DatabaseTransaction(DatabaseConnection connection, IsolationLevel isolationLevel)
        {
            this.connection = connection;
	        this.isolationLevel = isolationLevel;
        }

		public override IsolationLevel IsolationLevel
		{
			get { return isolationLevel; }
		}

        protected override DbConnection DbConnection
        {
            get { return connection; }
        }

        public override void Rollback()
        {
        }

		public override void Commit()
		{
		}
    }
}

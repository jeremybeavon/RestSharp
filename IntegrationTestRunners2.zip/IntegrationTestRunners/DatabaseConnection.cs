﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;

namespace Ax.UnitTests.IntegrationTestRunners
{
    internal sealed class DatabaseConnection : DbConnection, ICloneable
    {
        private readonly Database database;

        public DatabaseConnection(Database database)
        {
            this.database = database;
        }

        protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel)
        {
			database.StartTransaction();
            return new DatabaseTransaction(database, this);
        }

        public override void ChangeDatabase(string databaseName)
        {
        }

        public override void Close()
        {
        }

        public override string ConnectionString { get; set; }

        protected override DbCommand CreateDbCommand()
        {
            return new DatabaseCommand(database);
        }

        public override string DataSource
        {
            get { return null; }
        }

        public override string Database
        {
            get { return "Database"; }
        }

        public override void Open()
        {
        }

        public override string ServerVersion
        {
            get { return "1.0.0.0"; }
        }

        public override ConnectionState State
        {
            get { return ConnectionState.Open; }
        }

		public object Clone()
		{
			return this;
		}
	}
}

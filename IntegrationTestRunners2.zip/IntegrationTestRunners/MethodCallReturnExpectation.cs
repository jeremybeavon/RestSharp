﻿using System;
using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class MethodCallReturnExpectation : MethodCallExpectation
	{
		private readonly Func<object> returnValueFunc;
		private readonly IEnumerator<Func<object>> returnValues; 

		public MethodCallReturnExpectation(string methodDescription, int expectedCallCount, Func<object> returnValueFunc)
			: base(methodDescription, expectedCallCount)
		{
			this.returnValueFunc = returnValueFunc;
		}

		public MethodCallReturnExpectation(string methodDescription, int expectedCallCount, params Func<object>[] returnValues)
			: base(methodDescription, expectedCallCount)
		{
			this.returnValues = ((IEnumerable<Func<object>>)returnValues).GetEnumerator();
		}

		public T Return<T>()
		{
			RegisterCall();
			Func<object> returnValueBuilder = returnValueFunc;
			if (returnValueBuilder == null)
			{
				returnValues.MoveNext();
				returnValueBuilder = returnValues.Current;
			}

			object returnValue = returnValueBuilder();
			var exception = returnValue as Exception;
			if (exception != null)
			{
				throw exception;
			}

			return (T)returnValue;
		}
	}
}

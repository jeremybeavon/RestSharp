﻿using System;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[Serializable]
	public sealed class TestResult
	{
		public Exception TestException { get; set; }

		public Exception TearDownException { get; set; }

		public Exception TestFixtureTearDownException { get; set; }
	}
}

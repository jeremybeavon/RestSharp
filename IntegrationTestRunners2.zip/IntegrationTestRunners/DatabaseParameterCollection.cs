﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    internal sealed class DatabaseParameterCollection : DbParameterCollection
    {
        private readonly Dictionary<string, DatabaseParameter> parameterMap;
        private readonly IList parameters;
        private readonly IList<DatabaseParameter> stronglyTypedParameters;

        public DatabaseParameterCollection()
        {
            parameterMap = new Dictionary<string, DatabaseParameter>();
            List<DatabaseParameter> internalParameters = new List<DatabaseParameter>();
            parameters = internalParameters;
            stronglyTypedParameters = internalParameters;
        }

        public override int Add(object value)
        {
            DatabaseParameter parameter = (DatabaseParameter)value;
            parameterMap.Add(parameter.ParameterName, parameter);
            return parameters.Add(parameter);
        }

        public override void AddRange(Array values)
        {
            foreach (object value in values)
            {
                Add(value);
            }
        }

        public override void Clear()
        {
            parameters.Clear();
        }

        public override bool Contains(string value)
        {
            return parameterMap.ContainsKey(value);
        }

        public override bool Contains(object value)
        {
            return parameters.Contains((DatabaseParameter)value);
        }

        public override void CopyTo(Array array, int index)
        {
            parameters.CopyTo(array, index);
        }

        public override int Count
        {
            get { return parameters.Count; }
        }

        public override IEnumerator GetEnumerator()
        {
            return parameters.GetEnumerator();
        }

        protected override DbParameter GetParameter(string parameterName)
        {
            return parameterMap[parameterName];
        }

        protected override DbParameter GetParameter(int index)
        {
            return (DbParameter)parameters[index];
        }

        public override int IndexOf(string parameterName)
        {
            int index = 0;
            foreach (DatabaseParameter parameter in stronglyTypedParameters)
            {
                if (parameter.ParameterName == parameterName)
                {
                    return index;
                }

                index++;
            }

            return -1;
        }

        public override int IndexOf(object value)
        {
            return parameters.IndexOf(value);
        }

        public override void Insert(int index, object value)
        {
            parameters.Insert(index, value);
            DatabaseParameter parameter = (DatabaseParameter)value;
            parameterMap.Add(parameter.ParameterName, parameter);
        }

        public override bool IsFixedSize
        {
            get { return parameters.IsFixedSize; }
        }

        public override bool IsReadOnly
        {
            get { return parameters.IsFixedSize; }
        }

        public override bool IsSynchronized
        {
            get { return parameters.IsSynchronized; }
        }

        public override void Remove(object value)
        {
            parameters.Remove(value);
            parameterMap.Remove(((DatabaseParameter)value).ParameterName);
        }

        public override void RemoveAt(string parameterName)
        {
            DatabaseParameter parameter;
            if (parameterMap.TryGetValue(parameterName, out parameter))
            {
                parameterMap.Remove(parameterName);
                parameters.Remove(parameter);
            }
        }

        public override void RemoveAt(int index)
        {
            parameterMap.Remove(stronglyTypedParameters[index].ParameterName);
            parameters.RemoveAt(index);
        }

        protected override void SetParameter(string parameterName, DbParameter value)
        {
            RemoveAt(parameterName);
            Add(value);
        }

        protected override void SetParameter(int index, DbParameter value)
        {
            parameterMap.Remove(stronglyTypedParameters[index].ParameterName);
            parameters[index] = value;
            parameterMap.Add(value.ParameterName, (DatabaseParameter)value);
        }

        public override object SyncRoot
        {
            get { return parameters.SyncRoot; }
        }
    }
}

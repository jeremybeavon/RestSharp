﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Xml;
using NUnit.Core.Builders;
using NUnit.Core.Extensibility;
using NUnit.Framework;

namespace Ax.TestingCommon.UnitTests
{
    public static class BddAnalyzer
    {
        public static IEnumerable<TestDescription> GetTestDescriptionsForAssemblies(IEnumerable<Assembly> assemblies)
        {
            IEnumerable<MethodInfo> allTestMethods = assemblies
                .SelectMany(assembly => assembly.GetTypes())
                .Where(type => Attribute.IsDefined(type, typeof(TestFixtureAttribute)))
                .SelectMany(type => type.GetMethods())
                .Where(method => Attribute.IsDefined(method, typeof(TestAttribute)));
            return (from method in allTestMethods
                    let givenAttribute = GetAttribute<GivenAttribute>(method)
                    let whenAttribute = GetAttribute<WhenAttribute>(method)
                    let thenAttribute = GetAttribute<ThenAttribute>(method)
                    where givenAttribute != null && whenAttribute != null && thenAttribute != null
                    select new TestDescription
                    {
                        Method = method,
                        Given = givenAttribute.Given,
                        When = whenAttribute.WhenConditions,
                        Then = thenAttribute.ThenAssertions
                    }).SelectMany(ExpandTestDescriptions);
        }

        public static void GenerateStaticHtmlForAssemblies(IEnumerable<Assembly> assemblies, string outputFile)
        {
            var xmlText = new StringBuilder();
            var xmlSettings = new XmlWriterSettings
            {
                Indent = true
            };
            using (var writer = XmlWriter.Create(xmlText, xmlSettings))
            {
                writer.WriteStartElement("html");
                writer.WriteStartElement("body");
                writer.WriteStartElement("ul");
                GenerateStaticHtmlForTestDescriptions(GetTestDescriptionsForAssemblies(assemblies), writer);
                writer.WriteEndElement();
                writer.WriteEndElement();
                writer.WriteEndElement();
            }

            File.WriteAllText(outputFile, xmlText.ToString());
        }

        private static void GenerateStaticHtmlForTestDescriptions(IEnumerable<TestDescription> testDescriptions, XmlWriter writer)
        {
            var formattedTestDescriptions =
                from testDescription in testDescriptions
                group testDescription by testDescription.Given into givenGroup
                orderby givenGroup.Key
                select new
                {
                    Given = givenGroup.Key,
                    Then = from testDescription2 in givenGroup
                           from then in testDescription2.Then
                           group testDescription2 by then into thenGroup
                           orderby thenGroup.Key
                           select new
                           {
                               Then = thenGroup.Key,
                               When = from testDescription3 in thenGroup
                                      orderby string.Join(",", testDescription3.When)
                                      select testDescription3.When
                           }
                };
            foreach (var formattedTestDescription in formattedTestDescriptions)
            {
                writer.WriteStartElement("li");
                writer.WriteString(formattedTestDescription.Given);
                writer.WriteStartElement("ul");
                foreach (var givenDescription in formattedTestDescription.Then)
                {
                    writer.WriteStartElement("li");
                    writer.WriteString(givenDescription.Then);
                    GenerateStaticHtmlForWhenDescriptions(givenDescription.When, writer);
                    writer.WriteEndElement();
                }

                writer.WriteEndElement();
                writer.WriteEndElement();
            }
        }

        private static void GenerateStaticHtmlForWhenDescriptions(IEnumerable<string[]> whenDescriptions, XmlWriter writer)
        {
            writer.WriteStartElement("ul");
            foreach (string[] when in whenDescriptions)
            {
                writer.WriteStartElement("li");
                writer.WriteString("WHEN " + when[0]);
                foreach (string whenCondition in when.Skip(1))
                {
                    writer.WriteString(" AND ");
                    writer.WriteString(whenCondition);
                }

                writer.WriteEndElement();
            }

            writer.WriteEndElement();
        }

        private static IEnumerable<TestDescription> ExpandTestDescriptions(TestDescription testDescription)
        {
            MethodInfo testMethod = testDescription.Method;
            IEnumerable<object[]> testCaseArguments =
                GetTestCaseArguments(new TestCaseSourceProvider(), testMethod) ??
                GetTestCaseArguments(new TestCaseParameterProvider(), testMethod);
            if (testCaseArguments == null)
                return new[] { testDescription };

            ParameterInfo[] testParameters = testMethod.GetParameters();
            return from arguments in testCaseArguments
                   select new TestDescription
                   {
                       Method = testDescription.Method,
                       Given = testDescription.Given,
                       When = ReplaceParameterValues(testDescription.When, testParameters, arguments),
                       Then = ReplaceParameterValues(testDescription.Then, testParameters, arguments)
                   };
        }

        private static string[] ReplaceParameterValues(string[] text, ParameterInfo[] parameters, object[] values)
        {
            return text.Select(newText => ReplaceParameterValues(newText, parameters, values)).ToArray();
        }

        private static string ReplaceParameterValues(string text, ParameterInfo[] parameters, object[] values)
        {
            return parameters.Aggregate(text, (newText, parameter) => ReplaceParameterValue(newText, parameter, values));
        }

        private static string ReplaceParameterValue(string text, ParameterInfo parameter, object[] values)
        {
            return text.Replace("{" + parameter.Name + "}", (values[parameter.Position] ?? "null").ToString());
        }

        private static IEnumerable<object[]> GetTestCaseArguments(ITestCaseProvider provider, MethodInfo testMethod)
        {
            return provider.HasTestCasesFor(testMethod) ?
                provider.GetTestCasesFor(testMethod).Cast<ParameterSet>().Select(testCase => testCase.Arguments) :
                null;
        }

        private static T GetAttribute<T>(MethodInfo method)
            where T : Attribute
        {
            return Attribute.GetCustomAttribute(method, typeof(T)) as T;
        }
    }
}

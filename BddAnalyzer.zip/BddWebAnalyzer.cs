﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
using System.Xml;
using Ax.Services.Data;
using Ax.TestingCommon.UnitTests;
using Ax.UnitTests.Services.Impl.Mappers.Main;
using NUnit.Framework;

namespace Ax.Web.IntegrationTests.TestHelpers
{
	[TestFixture]
	public sealed class BddWebAnalyzer
	{
		private const BindingFlags bindingFlags = BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly;

		private static readonly Regex regex = new Regex(@"(?:^|(?<!\w))[A-Z]\w+", RegexOptions.Compiled);
		private static readonly Regex trueMatch = new Regex(@"(?:^|(?<!\w))true(?:(?!\w)|$)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

		[Test]
		[Explicit]
		public void BddGeneration()
		{
			GenerateStaticHtmlForControls(typeof(DCAsset), typeof(DCAssetVOContractContainerDataMapperTests), @"C:\Projects\test2.html");
		}

		public static void GenerateStaticHtmlForControls(Type dcType, Type testType, string outputFile)
		{
			var xmlText = new StringBuilder();
			var xmlSettings = new XmlWriterSettings
			{
				Indent = true
			};
			using (var writer = XmlWriter.Create(xmlText, xmlSettings))
			{
				writer.WriteStartElement("html");
				writer.WriteStartElement("body");
				writer.WriteStartElement("ul");
				GenerateStaticHtmlForControls(dcType, testType, writer);
				writer.WriteEndElement();
				writer.WriteEndElement();
				writer.WriteEndElement();
			}

			File.WriteAllText(outputFile, xmlText.ToString());
		}

		private static void GenerateStaticHtmlForControls(Type dcType, Type testType, XmlWriter writer)
		{
			IDictionary<string, TestDescription[]> testDescriptions = GetTestDescriptions(dcType, testType);
			IModelResourceManager resourceManager = new WebModelResourceManager();
			resourceManager.LoadEmbeddedResource("Ax.Web.Resources.ModelResources", typeof(AxHttpApplicationForWebTier).Assembly);
			IEnumerable<PropertyInfo> properties =
				from property in dcType.GetProperties(bindingFlags)
				let dataMember = GetCustomAttribute<DataMemberAttribute>(property)
				where dataMember != null && (dataMember.Order % 10 == 0 || dataMember.Order % 5 == 0)
				orderby dataMember.Order
				select property;
			foreach (PropertyInfo property in properties)
			{
				writer.WriteStartElement("li");
				string name = resourceManager.GetResourceStringFor(property.DeclaringType, property.Name);
				writer.WriteString(string.IsNullOrWhiteSpace(name) ? property.Name : name);
				writer.WriteStartElement("ul");
				RenderDcPropertyName(dcType, property.Name, writer);
				RenderCaption(GetCustomAttribute<CaptionAttribute>(property), testDescriptions, writer);
				var readOnlyAttribute = GetCustomAttribute<AxReadOnlyAttribute>(property);
				RenderAttribute(
					readOnlyAttribute == null ? null : readOnlyAttribute.MemberName,
					readOnlyAttribute != null && readOnlyAttribute.IsReadOnly,
					"Read-only", testDescriptions, writer);
				var enabledAttribute = GetCustomAttribute<EnabledAttribute>(property);
				RenderAttribute(
					enabledAttribute == null ? null : enabledAttribute.MemberName,
					(enabledAttribute != null && enabledAttribute.Value) || enabledAttribute == null,
					"Enabled", testDescriptions, writer);
				var visibleAttribute = GetCustomAttribute<VisibleAttribute>(property);
				RenderAttribute(
					visibleAttribute == null ? null : visibleAttribute.MemberName,
					(visibleAttribute != null && visibleAttribute.Value) || visibleAttribute == null,
					"Visible", testDescriptions, writer);
				writer.WriteEndElement();
				writer.WriteEndElement();
			}
		}

		private static void RenderDcPropertyName(Type dcType, string dcPropertyName, XmlWriter writer)
		{
			writer.WriteStartElement("li");
			writer.WriteElementString("b", "DC Property: ");
			writer.WriteString(dcType.Name + "." + dcPropertyName);
			writer.WriteEndElement();
		}

		private static void RenderCaption(CaptionAttribute captionAttribute, IDictionary<string, TestDescription[]> testDescriptions, XmlWriter writer)
		{
			TestDescription[] descriptions;
			if (captionAttribute == null || !testDescriptions.TryGetValue(captionAttribute.MemberName, out descriptions))
				return;

			var formattedTestDescriptions =
				from testDescription in descriptions
				from then in testDescription.Then
				group testDescription by then
				into thenGroup
				orderby thenGroup.Key
				select new
				{
					Then = thenGroup.Key,
					When = from testDescription2 in thenGroup
						orderby string.Join(",", testDescription2.When)
						select testDescription2.When
				};
			foreach (var formattedTestDescription in formattedTestDescriptions)
			{
				writer.WriteStartElement("li");
				writer.WriteRaw(Regex.Replace(HttpUtility.HtmlEncode(formattedTestDescription.Then), captionAttribute.MemberName, "<b>Caption</b>"));
				GenerateStaticHtmlForWhenDescriptions(formattedTestDescription.When, writer);
				writer.WriteEndElement();
			}
		}

		private static void GenerateStaticHtmlForWhenDescriptions(IEnumerable<string[]> whenDescriptions, XmlWriter writer)
		{
			writer.WriteStartElement("ul");
			foreach (string[] when in whenDescriptions)
			{
				writer.WriteElementString("li", "WHEN " + string.Join(" AND ", when));
			}

			writer.WriteEndElement();
		}

		private static void RenderAttribute(
			string memberName,
			bool value,
			string description,
			IDictionary<string, TestDescription[]> testDescriptions,
			XmlWriter writer)
		{
			writer.WriteStartElement("li");
			writer.WriteElementString("b", description + ": ");
			TestDescription[] descriptions;
			if (memberName == null)
				writer.WriteString(value ? "Always" : "Never");
			else if (!testDescriptions.TryGetValue(memberName, out descriptions))
				writer.WriteString("Unknown");
			else
			{
				writer.WriteString("WHEN:");
				writer.WriteStartElement("ul");
				var negativeDescriptions = new List<TestDescription>();
				foreach (TestDescription testDescription in descriptions)
				{
					if (testDescription.Then.Any(then => Regex.IsMatch(then, string.Format(@"(?:^|(?<!\w)){0}", memberName)) && trueMatch.IsMatch(then)))
						writer.WriteElementString("li", string.Join(" AND ", testDescription.When));
					else
						negativeDescriptions.Add(testDescription);
				}

				writer.WriteEndElement();
				RenderNegativeDescriptions(description, negativeDescriptions, writer);
			}

			writer.WriteEndElement();
		}

		private static void RenderNegativeDescriptions(string description, ICollection<TestDescription> testDescriptions, XmlWriter writer)
		{
			writer.WriteEndElement();
			writer.WriteStartElement("li");
			writer.WriteElementString("b", "NOT " + description + ": ");
			writer.WriteString("WHEN:");
			writer.WriteStartElement("ul");
			if (testDescriptions.Count == 0)
				writer.WriteString("Unknown");
			else
			{
				foreach (TestDescription testDescription in testDescriptions)
				{
					writer.WriteElementString("li", string.Join(" AND ", testDescription.When));
				}
			}

			writer.WriteEndElement();
		}

		private static IDictionary<string, TestDescription[]> GetTestDescriptions(Type dcType, Type testType)
		{
			return
				(from testDescription in BddAnalyzer.GetTestDescriptionsForAssemblies(new[] { testType.Assembly })
				 where testDescription.Method.DeclaringType == testType
				 from then in testDescription.Then
				 from thenProperty in regex.Matches(then).Cast<Match>().Select(match => match.Value)
				 join property in dcType.GetProperties(bindingFlags).Where(property => Attribute.IsDefined(property, typeof(DataMemberAttribute)))
					 on thenProperty equals property.Name
				 group testDescription by thenProperty
					 into testDescriptionsByPropertyName
					 select new
					 {
						 testDescriptionsByPropertyName.Key,
						 Values = testDescriptionsByPropertyName.ToArray()
					 }).ToDictionary(entry => entry.Key, entry => entry.Values);
		}

		private static T GetCustomAttribute<T>(MemberInfo member)
			where T : Attribute
		{
			return (T)Attribute.GetCustomAttribute(member, typeof(T));
		}
	}
}

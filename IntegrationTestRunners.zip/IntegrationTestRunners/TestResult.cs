﻿using System;
using System.Collections.Generic;
using NUnit.Framework;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[Serializable]
	public sealed class TestResult
	{
		public Exception TestException { get; set; }

		public Exception TearDownException { get; set; }

		public Exception TestFixtureTearDownException { get; set; }

		public void FailTestIfNecessary()
		{
			IList<Exception> exceptions = new List<Exception>();
			if (TestException != null)
			{
				exceptions.Add(TestException);
			}

			if (TearDownException != null)
			{
				exceptions.Add(TearDownException);
			}

			if (TestFixtureTearDownException != null)
			{
				exceptions.Add(TestFixtureTearDownException);
			}

			if (exceptions.Count != 0)
			{
				throw new AggregateException(exceptions);
			}
		}
	}
}

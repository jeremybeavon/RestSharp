﻿using System.Collections.Generic;
using System.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyDataReaderResultBuilder
	{
		public DummyDataReaderResultBuilder()
		{
			FieldNames = new string[0];
			Rows = new object[0][];
		}

		public DummyDataReaderResultBuilder(IDataRecord record)
		{
			FieldNames = new string[record.FieldCount];
			for (int index = 0; index < FieldNames.Length; index++)
			{
				FieldNames[index] = record.GetName(index);
			}

			Rows = new List<object[]>();
		}

		public string[] FieldNames { get; private set; }

		public IList<object[]> Rows { get; private set; }
	}
}

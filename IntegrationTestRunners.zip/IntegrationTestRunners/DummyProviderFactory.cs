﻿using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    public sealed class DummyProviderFactory : DbProviderFactory
    {
	    public DummyProviderFactory()
	    {
		    CommandRunner = new DummyCommandRunner();
	    }

	    public DummyCommandRunner CommandRunner { get; private set; }

        public override DbConnection CreateConnection()
        {
			return new DummyConnection(CommandRunner);
        }

        public override DbCommand CreateCommand()
        {
			return new DummyCommand(CommandRunner);
        }

        public override DbParameter CreateParameter()
        {
            return new DummyParameter();
        }

        public override DbDataAdapter CreateDataAdapter()
        {
            return new DummyDataAdapter();
        }
    }
}

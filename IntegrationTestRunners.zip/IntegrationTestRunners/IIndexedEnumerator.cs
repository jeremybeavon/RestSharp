﻿using System.Collections;
using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal interface IIndexedEnumerator : IEnumerator
	{
		int CurrentIndex { get; }

		int Length { get; }
	}

	internal interface IIndexedEnumerator<out T> : IIndexedEnumerator, IEnumerator<T>
	{
	}
}

﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Threading;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class ParallelTestRunner<TRemoteTestRunner, TRemoteTestParameter>
		where TRemoteTestRunner : RemoteTestRunner<TRemoteTestParameter>
		where TRemoteTestParameter : RemoteTestParameter
	{
		private readonly object integrationTestLock;
		private readonly Thread[] threads;
		private readonly IList<TRemoteTestParameter> methodsToRun;
		private readonly IDictionary<TRemoteTestParameter, TestResult> testResults;
		private readonly IDictionary<TRemoteTestParameter, Thread> currentlyRunningTests;
		private TRemoteTestParameter currentTest;
		private EventWaitHandle currentTestLock;

		public ParallelTestRunner()
		{
			integrationTestLock = new object();
			methodsToRun = new List<TRemoteTestParameter>();
			testResults = new Dictionary<TRemoteTestParameter, TestResult>();
			currentlyRunningTests = new Dictionary<TRemoteTestParameter, Thread>();
			//threads = new Thread[Environment.ProcessorCount];
			threads = new Thread[1];
		}

		private int MethodsToRunCount
		{
			get
			{
				lock (integrationTestLock)
				{
					return methodsToRun.Count;
				}
			}
		}

		public void TestFixtureSetUp(IEnumerable<TRemoteTestParameter> tests)
		{
			methodsToRun.AddRange(tests);
			for (int index = 0; index < threads.Length; index++)
			{
				threads[index] = new Thread(TestScheduler)
				{
					Name = string.Concat("ParallelTestRunner", index + 1)
				};
				threads[index].Start();
			}
		}

		public void TestFixtureTearDown()
		{
			lock (integrationTestLock)
			{
				bool interruptThreads = methodsToRun.Count != 0;
				methodsToRun.Clear();
				if (interruptThreads)
				{
					foreach (Thread thread in threads)
					{
						thread.Interrupt();	
					}
				}

				testResults.Clear();
				currentlyRunningTests.Clear();
			}
		}

		public TestResult RunTest(TRemoteTestParameter testParameter)
		{
			Thread thread = null;
			TestResult result;
			bool waitForTestToComplete = false;
			lock (integrationTestLock)
			{
				if (!testResults.TryGetValue(testParameter, out result))
				{
					waitForTestToComplete = true;
					if (!currentlyRunningTests.TryGetValue(testParameter, out thread))
					{
						methodsToRun.Remove(testParameter);
						methodsToRun.Insert(0, testParameter);
					}
				}
			}

			if (waitForTestToComplete)
			{
				result = WaitForTestToComplete(testParameter, thread);
			}

			lock (integrationTestLock)
			{
				testResults.Remove(testParameter);
			}

			return result;
		}

		private TestResult WaitForTestToComplete(TRemoteTestParameter testParameter, Thread thread)
		{
			if (thread == null)
			{
				lock (integrationTestLock)
				{
					currentTest = testParameter;
					currentTestLock = new EventWaitHandle(false, EventResetMode.ManualReset);
				}
				currentTestLock.WaitOne();
				lock (integrationTestLock)
				{
					currentTest = null;
					currentTestLock.Dispose();
					currentTestLock = null;
				}
			}
			else
			{
				thread.Join();
			}

			lock (integrationTestLock)
			{
				return testResults[testParameter];
			}
		}

		private void TestScheduler()
		{
			var setup = new AppDomainSetup
			{
				ApplicationBase = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
			};
			AppDomain domain = AppDomain.CreateDomain(Thread.CurrentThread.Name ?? "ParallelTestRunner", null, setup);
			try
			{
				var remoteTestRunner = (TRemoteTestRunner)domain.CreateInstanceAndUnwrap(
					typeof(TRemoteTestRunner).Assembly.GetName().ToString(),
					typeof(TRemoteTestRunner).FullName);
				var testRun = new TestRunner(this, remoteTestRunner);
				while (MethodsToRunCount != 0)
				{
					RunTest(testRun, new Thread(testRun.RunTest));
				}
			}
			finally
			{
				try
				{
					AppDomain.Unload(domain);
				}
				catch(AppDomainUnloadedException)
				{
				}
			}
		}

		private void RunTest(TestRunner testRunner, Thread testThread)
		{
			TRemoteTestParameter testToRun;
			lock (integrationTestLock)
			{
				testToRun = methodsToRun[0];
				methodsToRun.RemoveAt(0);
				currentlyRunningTests.Add(testToRun, testThread);
			}

			testRunner.RemoteTestParameter = testToRun;
			testThread.Name = testToRun.TestName;
			testThread.Start();
			try
			{
				testThread.Join();
			}
			catch (ThreadInterruptedException)
			{
				testThread.Abort();
			}

			lock (integrationTestLock)
			{
				currentlyRunningTests.Remove(testToRun);
				if (Equals(currentTest, testToRun))
				{
					currentTestLock.Set();
				}
			}
		}

		private sealed class TestRunner
		{
			private readonly ParallelTestRunner<TRemoteTestRunner, TRemoteTestParameter> parallelTestRunner;
			private readonly TRemoteTestRunner remoteTestRunner;

			public TestRunner(
				ParallelTestRunner<TRemoteTestRunner, TRemoteTestParameter> parallelTestRunner,
				TRemoteTestRunner remoteTestRunner)
			{
				this.parallelTestRunner = parallelTestRunner;
				this.remoteTestRunner = remoteTestRunner;
			}

			public TRemoteTestParameter RemoteTestParameter { get; set; }

			public void RunTest()
			{
				TestResult result = remoteTestRunner.RunTest(RemoteTestParameter);
				lock (parallelTestRunner.integrationTestLock)
				{
					parallelTestRunner.testResults.Add(RemoteTestParameter, result);
				}
			}
		}
	}
}

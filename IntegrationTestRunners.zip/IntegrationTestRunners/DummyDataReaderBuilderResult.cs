﻿using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyDataReaderBuilderResult : IndexedEnumerator<object[]>
	{
		public DummyDataReaderBuilderResult(ICollection<object[]> collection, string[] fieldNames)
			: base(collection)
		{
			FieldNames = fieldNames;
		}

		public string[] FieldNames { get; private set; }

	}
}

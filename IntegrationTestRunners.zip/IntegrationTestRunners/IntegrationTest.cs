﻿using Ax.Frameworks.BOF.Data;
using Ax.Frameworks.SysUtils;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class IntegrationTest
	{
		private IServiceInstanceProvider instanceProvider;

		public void SetUp()
		{
			instanceProvider = new IntegrationTestServiceInstanceProvider(CreateAdoHelper());
			ServiceFactory.ServiceInstanceProvider = instanceProvider;
		}

		public void TearDown()
		{
			ServiceFactory.ServiceInstanceProvider = null;
		}

		protected abstract IAdoHelper CreateAdoHelper();
	}
}

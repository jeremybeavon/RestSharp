﻿using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[TestFixture]
	public sealed class IntegrationTests
	{
		private static readonly IEnumerable<string> integrationTests =
			IntegrationTestRunner.AllTests.Where(testName => testName.StartsWith("Ax.IntegrationTests.BusinessRules"));

		private readonly IntegrationTestRunner testRunner;

		public IntegrationTests()
		{
			testRunner = new IntegrationTestRunner();
		}

		[TestFixtureSetUp]
		public void SetUp()
		{
			testRunner.TestFixtureSetUp(integrationTests);
		}

		[TestFixtureTearDown]
		public void TearDown()
		{
			testRunner.TestFixtureTearDown();
		}

		[Test]
		[TestCaseSource("integrationTests")]
		public void RunIntegrationTest(string testName)
		{
			testRunner.RunIntegrationTest(testName);
		}
	}
}

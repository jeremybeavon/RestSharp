﻿using System;
using System.Collections;
using System.Data;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal abstract class AbstractDummyDataReader<T> : DbDataReader
        where T : IIndexedEnumerator
	{
        private readonly IIndexedEnumerator<T> results;

		protected AbstractDummyDataReader(IIndexedEnumerator<T> results)
        {
            this.results = results;
			results.MoveNext();
        }

        public sealed override int Depth
        {
            get { return results.CurrentIndex; }
        }

        public sealed override bool HasRows
        {
            get { return results.Current.Length != 0; }
        }

		public override int RecordsAffected
		{
			get { return -1; }
		}
 
		public override bool IsClosed
		{
			get { return false; }
		}
 
		public sealed override object this[string name]
		{
			get { return GetValue(GetOrdinal(name)); }
		}
 
		public sealed override object this[int ordinal]
		{
			get { return GetValue(ordinal); }
		}
 
		public sealed override void Close()
		{
		}
 
		public sealed override bool GetBoolean(int ordinal)
		{
			return (bool)GetValue(ordinal);
		}
 
		public sealed override byte GetByte(int ordinal)
		{
			return (byte)GetValue(ordinal);
		}

        public sealed override long GetBytes(int ordinal, long dataOffset, byte[] buffer, int bufferOffset, int length)
        {
            return FillBuffer(ordinal, dataOffset, buffer, bufferOffset, length);
        }

        public sealed override long GetChars(int ordinal, long dataOffset, char[] buffer, int bufferOffset, int length)
        {
            return FillBuffer(ordinal, dataOffset, buffer, bufferOffset, length);
        }

		public sealed override char GetChar(int ordinal)
		{
			return (char)GetValue(ordinal);
		}
 
		public sealed override DateTime GetDateTime(int ordinal)
		{
			return (DateTime)GetValue(ordinal);
	
	}
 
		public sealed override decimal GetDecimal(int ordinal)
		{
			return (decimal)GetValue(ordinal);
		}
 
		public sealed override double GetDouble(int ordinal)
		{
			return (double)GetValue(ordinal);
		}

        public sealed override IEnumerator GetEnumerator()
        {
            return results.Current;
        }
 
		public sealed override float GetFloat(int ordinal)
		{
			return (float)GetValue(ordinal);
		}
 
		public sealed override Guid GetGuid(int ordinal)
		{
			return (Guid)GetValue(ordinal);
		}
 
		public sealed override short GetInt16(int ordinal)
		{
			return (short)GetValue(ordinal);
		}
 
		public sealed override int GetInt32(int ordinal)
		{
			return (int)GetValue(ordinal);
		}
 
		public sealed override long GetInt64(int ordinal)
		{
			return (long)GetValue(ordinal);
		}
 
		public sealed override string GetString(int ordinal)
	
	{
			return (string)GetValue(ordinal);
		}

        public sealed override int GetValues(object[] values)
        {
            int size = Math.Min(values.Length, FieldCount);
            for (int index = 0; index < size; index++)
            {
                values[index] = GetValue(index);
            }

            return size;
        }

        public sealed override bool IsDBNull(int ordinal)
		{
			object value = GetValue(ordinal);
	        return value == null || value is DBNull;
		}
 
		public override string GetDataTypeName(int ordinal)
		{
			throw new NotImplementedException();
		}
 
		public override DataTable GetSchemaTable()
		{
			throw new NotImplementedException();
		}

        public sealed override bool NextResult()
        {
            return results.MoveNext();
        }

        public sealed override bool Read()
        {
            return results.Current.MoveNext();
        }

        private long FillBuffer<TValue>(int ordinal, long dataOffset, TValue[] buffer, int bufferOffset, int length)
        {
			var data = (TValue[])GetValue(ordinal);
            long size = 0;
            for (int index = 0; index < length; index++)
            {
                long dataIndex = dataOffset + index;
                int bufferIndex = bufferOffset + index;
                if (dataIndex >= data.Length || bufferIndex >= buffer.Length)
                {
                    break;
                }

                size++;
                buffer[bufferIndex] = data[dataIndex];
            }

            return size;
        }
	}
}

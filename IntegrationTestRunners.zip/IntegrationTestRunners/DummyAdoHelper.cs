﻿using System.Collections;
using System.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class DummyAdoHelper : AbstractDummyAdoHelper<DummyProviderFactory>, IEnumerable
	{
		public DummyAdoHelper()
			: base(new DummyProviderFactory())
		{
		}

		public DummyCommandRunner CommandRunner
		{
			get { return ProviderFactory.CommandRunner; }
		}

		public void Add(DummyCommand expectedCommand)
		{
			CommandRunner.Add(expectedCommand);
		}

		public override void DeriveParameters(IDbCommand cmd)
		{
			CommandRunner.DeriveParameters(cmd);
		}

		public IEnumerator GetEnumerator()
		{
			yield break;
		}
	}
}

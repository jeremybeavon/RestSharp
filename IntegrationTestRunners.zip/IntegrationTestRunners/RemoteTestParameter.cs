﻿using System;

namespace Ax.UnitTests.IntegrationTestRunners
{
	[Serializable]
	public class RemoteTestParameter : IEquatable<RemoteTestParameter>
	{
		public RemoteTestParameter()
		{
		}

		public RemoteTestParameter(string testName)
		{
			TestName = testName;
		}

		public string TestName { get; private set; }

		public sealed override int GetHashCode()
		{
			return TestName.GetHashCode();
		}

		public override bool Equals(object obj)
		{
			return Equals(obj as RemoteTestParameter);
		}

		public bool Equals(RemoteTestParameter other)
		{
			return other != null && TestName == other.TestName;
		}
	}
}

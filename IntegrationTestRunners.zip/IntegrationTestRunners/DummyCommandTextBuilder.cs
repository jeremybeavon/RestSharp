﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyCommandTextBuilder
	{
		private static readonly IDictionary<TypeCode, string> predefinedTypeNames = new Dictionary<TypeCode, string>
		{
			{TypeCode.Boolean, "bool"},
			{TypeCode.Char, "char"},
			{TypeCode.SByte, "sbyte"},
			{TypeCode.Byte, "byte"},
			{TypeCode.Int16, "short"},
			{TypeCode.UInt16, "ushort"},
			{TypeCode.Int32, "int"},
			{TypeCode.UInt32, "uint"},
			{TypeCode.Int64, "long"},
			{TypeCode.UInt64, "ulong"},
			{TypeCode.Single, "float"},
			{TypeCode.Double, "double"},
			{TypeCode.Decimal, "decimal"},
			{TypeCode.String, "string"}
		};

		private readonly StringBuilder textBuilder;
        private readonly HashSet<int> commas;
        private int? currentIndent;

		public DummyCommandTextBuilder()
	    {
            textBuilder = new StringBuilder();
            commas = new HashSet<int>();
	    }

        public IDisposable ApplyIndent(int indent)
        {
            return new IndentApplier(this, indent);
        }

		public DummyCommandTextBuilder AppendLineWithCommaAndIndent()
        {
            if (currentIndent == null)
            {
                throw new InvalidOperationException();
            }

            if (!commas.Add(currentIndent.Value))
            {
                textBuilder.Append(",");
            }

            textBuilder.AppendLine();
            return AppendIndent(currentIndent.Value);
        }

		public DummyCommandTextBuilder AppendIndent(int indent)
        {
            return Append(string.Empty.PadLeft(indent, '\t'));
        }

		public DummyCommandTextBuilder Append(int value)
		{
			textBuilder.Append(value);
			return this;
		}

		public DummyCommandTextBuilder Append(string text)
        {
            textBuilder.Append(text);
            return this;
        }

		public DummyCommandTextBuilder Append(string format, params object[] arguments)
        {
            textBuilder.AppendFormat(format, arguments);
            return this;
        }

		public DummyCommandTextBuilder AppendTypeName(Type type)
        {
			textBuilder.Append(GetTypeName(type));
            return this;
        }

		public DummyCommandTextBuilder AppendConstant(object value)
		{
			if (value == null || value is DBNull)
			{
				textBuilder.Append("null");
			}

			if (!AppendByteArray(value as byte[]))
			{
				textBuilder.Append(GetConstantValueFromTypeCode(value));
			}

			return this;
        }

		public DummyCommandTextBuilder AppendLine()
		{
			textBuilder.AppendLine();
			return this;
		}

		public DummyCommandTextBuilder AppendLine(string text)
        {
            textBuilder.AppendLine(text);
            return this;
        }

        public DummyCommandTextBuilder AppendLine(string format, params object[] arguments)
        {
            textBuilder.AppendFormat(format, arguments).AppendLine();
            return this;
        }

        public override string ToString()
        {
            return textBuilder.ToString();
        }

		private static string GetTypeName(Type type)
		{
			string predefinedTypeName;
			if (!type.IsEnum && predefinedTypeNames.TryGetValue(Type.GetTypeCode(type), out predefinedTypeName))
			{
				return predefinedTypeName;
			}

			var typeName = new StringBuilder();
			BuildTypeName(type, typeName);
			return typeName.ToString();
		}

		private static void BuildTypeName(Type type, StringBuilder typeName)
		{
			if (type.DeclaringType != null && !type.IsGenericParameter)
			{
				typeName.Append(GetTypeName(type.DeclaringType)).Append(".");
			}

			typeName.Append(type.IsArray ? GetArrayTypeName(type) : type.Name);
		}

		private static string GetArrayTypeName(Type type)
		{
			return string.Concat(GetTypeName(type.GetElementType()), "[", string.Empty.PadLeft(type.GetArrayRank() - 1, ','), "]");
		}

		private static string GetConstantValueFromTypeCode(object value)
		{
			switch (Type.GetTypeCode(value.GetType()))
			{
				case TypeCode.Char:
					return string.Format("'{0}'", value);
				case TypeCode.String:
					return string.Format("@\"{0}\"", value.ToString().Replace("\"", "\"\""));
				case TypeCode.DateTime:
					return GetDateString((DateTime)value);
				case TypeCode.Decimal:
					return string.Concat(value, "m");
				default:
					return value.ToString().ToLower();
			}
		}

		private static string GetDateString(DateTime date)
		{
			return string.Format(
				"new DateTime({0}, {1}, {2}, {3}, {4}, {5}, {6})",
				date.Year,
				date.Month,
				date.Day,
				date.Hour,
				date.Minute,
				date.Second,
				date.Millisecond);
		}

		private bool AppendByteArray(byte[] bytes)
		{
			if (bytes == null)
			{
				return false;
			}

			int indent = currentIndent ?? 0;
			textBuilder.AppendLine("new byte[]");
			AppendIndent(indent).AppendLine("{");
			indent++;
			string comma = string.Empty;
			for (int index = 0; index < bytes.Length; index++)
			{
				textBuilder.Append(comma).Append(bytes[index]);
				if (index % 10 == 0)
				{
					AppendLine().AppendIndent(indent);
				}

				comma = ", ";
			}

			indent--;
			AppendIndent(indent).Append("{");
			return true;
		}

		private sealed class IndentApplier : IDisposable
        {
			private readonly DummyCommandTextBuilder commandTextBuilder;
            private readonly int? oldIndent;
            private readonly int newIndent;

			public IndentApplier(DummyCommandTextBuilder commandTextBuilder, int newIndent)
            {
				this.commandTextBuilder = commandTextBuilder;
				oldIndent = commandTextBuilder.currentIndent;
                this.newIndent = newIndent;
				commandTextBuilder.currentIndent = newIndent;
            }

            public void Dispose()
            {
				commandTextBuilder.currentIndent = oldIndent;
				commandTextBuilder.commas.Remove(newIndent);
            }
        }
	}
}

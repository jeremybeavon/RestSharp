﻿using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    public sealed class DummyDataAdapter : DbDataAdapter
    {
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Ax.Frameworks.BOF;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyDataReader : AbstractDummyDataReader<DummyDataReaderResult>
	{
		private readonly IIndexedEnumerator<DummyDataReaderResult> results;

        public DummyDataReader(ICollection<object[]> results)
            : this(GetResults(results))
        {
        }

		private DummyDataReader(IIndexedEnumerator<DummyDataReaderResult> results)
            : base(results)
		{
			this.results = results;
		}

		public override int FieldCount
		{
			get { return results.Current.FieldCount; }
		}
 
		public override Type GetFieldType(int ordinal)
		{
			return GetProperty(ordinal).PropertyType;
		}
 
		public override string GetName(int ordinal)
		{
			return GetProperty(ordinal).Name;
		}
 
		public override int GetOrdinal(string name)
		{
			PropertyInfo[] properties = results.Current.Current.GetType().GetProperties();
			return Array.IndexOf(properties, properties.First(property => property.Name == name));
		}
 
		public override object GetValue(int ordinal)
		{
			return BOFDynamicCalls.GetPropertyGetter(GetProperty(ordinal))(results.Current.Current) ?? DBNull.Value;
		}

		private static IIndexedEnumerator<DummyDataReaderResult> GetResults(ICollection<object[]> results)
        {
			return new IndexedEnumerator<DummyDataReaderResult>(
				results.Select(result => new DummyDataReaderResult(result)).GetEnumerator(),
                results.Count);
        }
 
		private PropertyInfo GetProperty(int ordinal)
		{
			return results.Current.Current.GetType().GetProperties()[ordinal];
		}
	}
}

﻿using System;
using System.Data;
using System.Data.Common;
using System.Xml;
using Ax.Frameworks.BOF.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class AbstractDummyAdoHelper<TProviderFactory> : AdoHelper
		where TProviderFactory : DbProviderFactory
	{
		private readonly TProviderFactory providerFactory;

		protected AbstractDummyAdoHelper(TProviderFactory providerFactory)
		{
			this.providerFactory = providerFactory;
		}

		protected TProviderFactory ProviderFactory
		{
			get { return providerFactory; }
		}

		public override IDbConnection GetConnection(string connectionString)
		{
			IDbConnection connection = providerFactory.CreateConnection();
			if (connection != null)
			{
				connection.ConnectionString = connectionString;
			}

			return connection;
		}

		public override IDbDataAdapter GetDataAdapter()
		{
			return providerFactory.CreateDataAdapter();
		}

		public override IDataParameter GetParameter()
		{
			return providerFactory.CreateParameter();
		}

		public override string GetConcatOperator()
		{
			return "+";
		}

		public override XmlReader ExecuteXmlReader(IDbCommand cmd)
		{
			throw new NotImplementedException();
		}

		protected override void AddUpdateEventHandlers(
			IDbDataAdapter dataAdapter,
			RowUpdatingHandler rowUpdatingHandler,
			RowUpdatedHandler rowUpdatedHandler)
		{
			throw new NotImplementedException();
		}

		protected override IDataParameter[] GetDataParameters(int size)
		{
			var parameters = new IDataParameter[size];
			for (int index = 0; index < size; index++)
			{
				parameters[index] = providerFactory.CreateParameter();
			}

			return parameters;
		}

		protected override IDataParameter GetBlobParameter(IDbTransaction tx, IDataParameter p)
		{
			return providerFactory.CreateParameter();
		}

		public override void ClearDbPool()
		{
		}
	}
}

﻿using System;
using System.Data;
using Ax.Frameworks.BOF.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyAdoHelperBuilder : AbstractDummyAdoHelper<DummyProviderFactoryBuilder>
	{
		public DummyAdoHelperBuilder(DummyCommandTextBuilder textBuilder)
			: base(new DummyProviderFactoryBuilder(textBuilder))
		{
		}

		public IAdoHelper AdoHelper { get; set; }

		public override void DeriveParameters(IDbCommand cmd)
		{
			((DummyCommandBuilder)cmd).DeriveParameters(AdoHelper);
		}
	}
}

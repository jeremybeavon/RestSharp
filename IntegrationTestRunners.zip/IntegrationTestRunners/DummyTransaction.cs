﻿using System.Data;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    internal sealed class DummyTransaction : DbTransaction
    {
        private readonly DummyConnection connection;
	    private readonly IsolationLevel isolationLevel;

        public DummyTransaction(DummyConnection connection, IsolationLevel isolationLevel)
        {
            this.connection = connection;
	        this.isolationLevel = isolationLevel;
        }

		public override IsolationLevel IsolationLevel
		{
			get { return isolationLevel; }
		}

        protected override DbConnection DbConnection
        {
            get { return connection; }
        }

        public override void Rollback()
        {
        }

		public override void Commit()
		{
		}
    }
}

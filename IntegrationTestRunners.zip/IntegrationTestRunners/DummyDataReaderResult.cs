﻿namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyDataReaderResult : IndexedEnumerator
	{
		public DummyDataReaderResult(object[] result)
			: base(result)
		{
			FieldCount = result.Length == 0 ? 0 : result[0].GetType().GetProperties().Length;
		}

		public int FieldCount { get; private set; }
	}
}

﻿using System.Data;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    public sealed class DummyCommand : DbCommand
    {
		private readonly DummyCommandRunner commandRunner;
        private readonly DbParameterCollection parameters;

	    public DummyCommand()
	    {
			parameters = new DummyParameterCollection();
	    }

		internal DummyCommand(DummyCommandRunner commandRunner)
			: this()
        {
	        this.commandRunner = commandRunner;
        }

        public override void Cancel()
        {
        }

        public override string CommandText { get; set; }

        public override int CommandTimeout { get; set; }

        public override CommandType CommandType { get; set; }

	    public DummyCommandType DummyCommandType { get; set; }

	    public int NonQueryResult { get; set; }

	    public object ScalarResult { get; set; }

	    public object[][] ReaderResult { get; set; }

	    public new DummyParameterCollection Parameters
	    {
		    get { return (DummyParameterCollection)base.Parameters; }
	    }

        protected override DbParameter CreateDbParameter()
        {
            return new DummyParameter();
        }

        protected override DbConnection DbConnection { get; set; }

        protected override DbParameterCollection DbParameterCollection 
        {
            get { return parameters; }
        }

        protected override DbTransaction DbTransaction { get; set; }

        public override bool DesignTimeVisible { get; set; }

        public override UpdateRowSource UpdatedRowSource { get; set; }

        protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
        {
	        return commandRunner.ExecuteReader(this);
        }

        public override int ExecuteNonQuery()
        {
	        return commandRunner.ExecuteNonQuery(this);
        }

        public override object ExecuteScalar()
        {
	        return commandRunner.ExecuteScalar(this);
        }

        public override void Prepare()
        {
        }
    }
}

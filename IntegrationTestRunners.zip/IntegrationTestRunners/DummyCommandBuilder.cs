﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using Ax.Frameworks.BOF.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyCommandBuilder : DbCommand
	{
		private readonly SqlCommand command;
		private readonly DummyCommandTextBuilder textBuilder;
		private DummyConnectionBuilder connection;
		private DummyTransactionBuilder transaction;

		public DummyCommandBuilder(SqlCommand command, DummyConnectionBuilder connection, DummyCommandTextBuilder textBuilder)
		{
			this.command = command;
			this.connection = connection;
			this.textBuilder = textBuilder;
		}

		public override string CommandText
		{
			get { return command.CommandText; }
			set { command.CommandText = value; }
		}

		public override int CommandTimeout
		{
			get { return command.CommandTimeout; }
			set { command.CommandTimeout = value; }
		}

		public override CommandType CommandType
		{
			get { return command.CommandType; }
			set { command.CommandType = value; }
		}

		protected override DbParameter CreateDbParameter()
		{
			return new SqlParameter();
		}

		protected override DbConnection DbConnection
		{
			get { return connection; }
			set
			{
				connection = (DummyConnectionBuilder)value;
				command.Connection = connection.Connection;
			}
		}

		protected override DbParameterCollection DbParameterCollection
		{
			get { return command.Parameters; }
		}

		protected override DbTransaction DbTransaction
		{
			get { return transaction; }
			set
			{
				transaction = (DummyTransactionBuilder)value;
				command.Transaction = transaction == null ? null : transaction.Transaction;
			}
		}

		public override bool DesignTimeVisible
		{
			get { return command.DesignTimeVisible; }
			set { command.DesignTimeVisible = value; }
		}

		public override UpdateRowSource UpdatedRowSource
		{
			get { return command.UpdatedRowSource; }
			set { command.UpdatedRowSource = value; }
		}

		public override void Cancel()
		{
			command.Cancel();
		}

		protected override DbDataReader ExecuteDbDataReader(CommandBehavior behavior)
		{
			StartWritingCommand(DummyCommandType.Reader);
			textBuilder.AppendIndent(5).AppendLine("ReaderResult = new object[][]");
			textBuilder.AppendIndent(5).Append("{");
			ICollection<DummyDataReaderResultBuilder> results = new List<DummyDataReaderResultBuilder>();
			using (DbDataReader reader = command.ExecuteReader(behavior))
			{
				ReadDataReader(reader, results);
			}

			textBuilder.AppendIndent(5).AppendLine("}");
			FinishWritingCommand();
			return new DummyDataReaderBuilder(results);
		}

		public override int ExecuteNonQuery()
		{
			int result = command.ExecuteNonQuery();
			StartWritingCommand(DummyCommandType.NonQuery);
			textBuilder.AppendIndent(5).Append("NonQueryResult = ");
			textBuilder.Append(result).AppendLine();
			FinishWritingCommand();
			return result;
		}

		public override object ExecuteScalar()
		{
			object result = command.ExecuteScalar();
			StartWritingCommand(DummyCommandType.Scalar);
			textBuilder.AppendIndent(5).Append("ScalarResult = ");
			textBuilder.AppendConstant(result).AppendLine();
			FinishWritingCommand();
			return result;
		}

		public void DeriveParameters(IAdoHelper adoHelper)
		{
			adoHelper.DeriveParameters(command);
			StartWritingCommand(DummyCommandType.DeriveParameters);
			FinishWritingCommand();
		}

		public override void Prepare()
		{
			command.Prepare();
		}

		private void StartWritingCommand(DummyCommandType commandType)
		{
			textBuilder.AppendLineWithCommaAndIndent().AppendLine("new DummyCommand");
			textBuilder.AppendIndent(4).AppendLine("{");
			textBuilder.AppendIndent(5).Append("CommandText = ").AppendConstant(CommandText).AppendLine(",");
			textBuilder.AppendIndent(5).AppendLine("DummyCommandType = DummyCommandType.{0},", commandType);
			if (Parameters.Count != 0)
			{
				WriteParameters(commandType);
			}
		}

		private void WriteParameters(DummyCommandType commandType)
		{
			textBuilder.AppendIndent(5).AppendLine("Parameters =");
			textBuilder.AppendIndent(5).Append("{");
			using (textBuilder.ApplyIndent(6))
			{
				foreach (IDataParameter parameter in Parameters)
				{
					textBuilder
						.AppendLineWithCommaAndIndent()
						.Append("new DummyParameter(")
						.AppendConstant(parameter.ParameterName)
						.Append(", ")
						.AppendConstant(parameter.Value)
						.Append(", ParameterDirection.{0}", parameter.Direction)
						.Append(")");
				}
			}

			textBuilder.AppendLine();
			textBuilder.AppendIndent(5).Append("}");
			if (commandType != DummyCommandType.DeriveParameters)
			{
				textBuilder.Append(",");
			}

			textBuilder.AppendLine();
		}

		private void FinishWritingCommand()
		{
			textBuilder.AppendIndent(4).Append("}");
		}

		private void ReadDataReader(IDataReader reader, ICollection<DummyDataReaderResultBuilder> results)
		{
			using (textBuilder.ApplyIndent(6))
			{
				results.Add(ReadDataReaderResult(reader));
				while (reader.NextResult())
				{
					results.Add(ReadDataReaderResult(reader));
				}
			}
		}

		private DummyDataReaderResultBuilder ReadDataReaderResult(IDataReader reader)
		{
			if (reader.Read())
			{
				var result = new DummyDataReaderResultBuilder(reader);
				textBuilder.AppendLineWithCommaAndIndent().AppendLine("new[]");
				textBuilder.AppendIndent(6).Append("{");
				using (textBuilder.ApplyIndent(7))
				{
					result.Rows.Add(ReadDataRecord(reader));
					while (reader.Read())
					{
						result.Rows.Add(ReadDataRecord(reader));
					}
				}

				textBuilder.AppendLine();
				textBuilder.AppendIndent(6).AppendLine("}");
				return result;
			}
			
			textBuilder.AppendLineWithCommaAndIndent().AppendLine("new object[0]");
			return new DummyDataReaderResultBuilder();
		}

		private object[] ReadDataRecord(IDataRecord record)
        {
            var values = new object[record.FieldCount];
            record.GetValues(values);
            textBuilder.AppendLineWithCommaAndIndent().AppendLine("new");
            textBuilder.AppendIndent(7).Append("{");
            using (textBuilder.ApplyIndent(8))
            {
                for (int index = 0; index < values.Length; index++)
                {
                    textBuilder.AppendLineWithCommaAndIndent().Append(record.GetName(index)).Append(" = ");
                    Type fieldType = record.GetFieldType(index);
                    if (fieldType.IsValueType)
                    {
                        textBuilder.Append("(").AppendTypeName(fieldType).Append("?)");
                    }
					else if (values[index] == null || values[index] is DBNull)
					{
						textBuilder.Append("(").AppendTypeName(fieldType).Append(")");
					}

                    textBuilder.AppendConstant(values[index]);
                }
            }

			textBuilder.AppendLine();
            textBuilder.AppendIndent(7).Append("}");
			return values;
        }
	}
}

﻿using System.Data;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class SerializableDummyParameter
	{
		public string ParameterName { get; set; }

		public object ParameterValue { get; set; }

		public ParameterDirection Direction { get; set; }
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class SerializableDummyCommand
	{
		public string CommandText { get; set; }

		public DummyCommandType DummyCommandType { get; set; }

		public List<SerializableDummyParameter> Parameters { get; set; }

		public int NonQueryResult { get; set; }

		public object ScalarResult { get; set; }


	}
}

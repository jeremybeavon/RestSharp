﻿using System.Data.Common;
using System.Data.SqlClient;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyProviderFactoryBuilder : DbProviderFactory
	{
		private readonly DummyCommandTextBuilder textBuilder;

		public DummyProviderFactoryBuilder(DummyCommandTextBuilder textBuilder)
		{
			this.textBuilder = textBuilder;
		}

		public override DbConnection CreateConnection()
		{
			return new DummyConnectionBuilder(new SqlConnection(), textBuilder);
		}

		public override DbCommand CreateCommand()
		{
			return new DummyCommandBuilder(new SqlCommand(), null, textBuilder);
		}

		public override DbParameter CreateParameter()
		{
			return new SqlParameter();
		}

		public override DbDataAdapter CreateDataAdapter()
		{
			return new DummyDataAdapter();
		}
	}
}

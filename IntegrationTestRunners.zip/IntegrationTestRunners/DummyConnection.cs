﻿using System;
using System.Data;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
    public sealed class DummyConnection : AbstractDummyConnection
    {
		private readonly DummyCommandRunner commandRunner;

		public DummyConnection(DummyCommandRunner commandRunner)
        {
            this.commandRunner = commandRunner;
        }

        protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel)
        {
            return new DummyTransaction(this, isolationLevel);
        }

        public override void ChangeDatabase(string databaseName)
        {
        }

        public override void Close()
        {
        }

        public override string ConnectionString { get; set; }

        protected override DbCommand CreateDbCommand()
        {
            return new DummyCommand(commandRunner);
        }

        public override string DataSource
        {
            get { return null; }
        }

        public override string Database
        {
            get { return "Database"; }
        }

        public override void Open()
        {
        }

        public override string ServerVersion
        {
            get { return "1.0.0.0"; }
        }

        public override ConnectionState State
        {
            get { return ConnectionState.Open; }
        }

		public override object Clone()
		{
			return this;
		}
	}
}

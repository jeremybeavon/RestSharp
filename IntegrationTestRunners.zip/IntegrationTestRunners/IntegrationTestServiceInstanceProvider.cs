﻿using System;
using Ax.Frameworks.BOF.Data;
using Ax.Frameworks.SysUtils;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class IntegrationTestServiceInstanceProvider : IServiceInstanceProvider
	{
		private readonly IAdoHelper adoHelper;

		public IntegrationTestServiceInstanceProvider(IAdoHelper adoHelper)
		{
			this.adoHelper = adoHelper;
		}

		public T Resolve<T>(Func<T> constructor)
			where T : class
		{
			return typeof(T) == typeof(IAdoHelper) ? (T)adoHelper : constructor();
		}
	}
}

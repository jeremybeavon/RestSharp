﻿namespace Ax.UnitTests.IntegrationTestRunners
{
	public enum DummyCommandType
	{
		Scalar,
		NonQuery,
		Reader,
		DeriveParameters
	}
}

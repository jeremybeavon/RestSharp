﻿using System;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyConnectionBuilder : AbstractDummyConnection
	{
		private readonly SqlConnection connection;
		private readonly DummyCommandTextBuilder textBuilder;

		public DummyConnectionBuilder(SqlConnection connection, DummyCommandTextBuilder textBuilder)
		{
			this.connection = connection;
			this.textBuilder = textBuilder;
		}

		public SqlConnection Connection
		{
			get { return connection; }
		}

		public override string DataSource
		{
			get { return connection.DataSource; }
		}

		public override string Database
		{
			get { return connection.Database; }
		}

		public override string ServerVersion
		{
			get { return connection.ServerVersion; }
		}

		public override ConnectionState State
		{
			get { return connection.State; }
		}

		protected override DbTransaction BeginDbTransaction(IsolationLevel isolationLevel)
		{
			return new DummyTransactionBuilder(connection.BeginTransaction(isolationLevel), this);
		}

		public override void ChangeDatabase(string databaseName)
		{
			connection.ChangeDatabase(databaseName);
		}

		public override void Close()
		{
			connection.Close();
		}

		public override string ConnectionString
		{
			get { return connection.ConnectionString; }
			set { connection.ConnectionString = value; }
		}

		protected override DbCommand CreateDbCommand()
		{
			return new DummyCommandBuilder(connection.CreateCommand(), this, textBuilder);
		}

		public override void Open()
		{
			connection.Open();
		}

		public override object Clone()
		{
			return new DummyConnectionBuilder((SqlConnection)((ICloneable)connection).Clone(), textBuilder);
		}
	}
}

﻿using System.Data;
using System.Data.Common;
using System.Data.SqlClient;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyTransactionBuilder : DbTransaction
	{
		private readonly SqlTransaction transaction;
		private readonly DummyConnectionBuilder connection;

		public DummyTransactionBuilder(SqlTransaction transaction, DummyConnectionBuilder connection)
		{
			this.transaction = transaction;
			this.connection = connection;
		}

		public override IsolationLevel IsolationLevel
		{
			get { return transaction.IsolationLevel; }
		}

		public SqlTransaction Transaction
		{
			get { return transaction; }
		}

		protected override DbConnection DbConnection
		{
			get { return connection; }
		}

		public override void Commit()
		{
			transaction.Commit();
		}

		public override void Rollback()
		{
			transaction.Rollback();
		}
	}
}

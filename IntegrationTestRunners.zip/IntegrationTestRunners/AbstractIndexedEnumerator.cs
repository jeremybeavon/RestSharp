﻿using System.Collections;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal abstract class AbstractIndexedEnumerator
	{
		private readonly IEnumerator enumerator;
		private readonly int length;
		private int currentIndex;

		protected AbstractIndexedEnumerator(IEnumerator enumerator, int length)
		{
			this.enumerator = enumerator;
			this.length = length;
			currentIndex = -1;
		}

		public int CurrentIndex
		{
			get { return currentIndex; }
		}

		public int Length
		{
			get { return length; }
		}

		public bool MoveNext()
		{
			currentIndex++;
			return enumerator.MoveNext();
		}

		public void Reset()
		{
			enumerator.MoveNext();
		}
	}
}

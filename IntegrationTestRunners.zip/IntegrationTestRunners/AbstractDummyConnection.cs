﻿using System;
using System.Data.Common;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public abstract class AbstractDummyConnection : DbConnection, ICloneable
	{
		public abstract object Clone();
	}
}

﻿namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class SerializableDataReaderResult
	{
		public object[][] Rows { get; set; }

		public string[] FieldNames { get; set; }
	}
}

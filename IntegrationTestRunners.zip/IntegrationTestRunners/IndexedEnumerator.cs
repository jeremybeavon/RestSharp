﻿using System.Collections;
using System.Collections.Generic;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal class IndexedEnumerator : AbstractIndexedEnumerator, IIndexedEnumerator
	{
		private readonly IEnumerator enumerator;

		public IndexedEnumerator(ICollection collection)
			: this(collection.GetEnumerator(), collection.Count)
		{
		}

		public IndexedEnumerator(IEnumerator enumerator, int length)
			: base(enumerator, length)
		{
			this.enumerator = enumerator;
		}

		public object Current
		{
			get { return enumerator.Current; }
		}
	}

	internal class IndexedEnumerator<T> : AbstractIndexedEnumerator, IIndexedEnumerator<T>
	{
		private readonly IEnumerator<T> enumerator;

		public IndexedEnumerator(ICollection<T> collection)
			: this(collection.GetEnumerator(), collection.Count)
		{
		}

		public IndexedEnumerator(IEnumerator<T> enumerator, int length)
			: base(enumerator, length)
		{
			this.enumerator = enumerator;
		}

		public T Current
		{
			get { return enumerator.Current; }
		}

		object IEnumerator.Current
		{
			get { return Current; }
		}

		public void Dispose()
		{
			enumerator.Dispose();
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using NUnit.Framework;

namespace Ax.UnitTests.IntegrationTestRunners
{
	public sealed class DummyCommandRunner
	{
		private readonly Queue<DummyCommand> expectedCommands;

		public DummyCommandRunner()
		{
			expectedCommands = new Queue<DummyCommand>();
		}

		public void Add(DummyCommand expectedCommand)
		{
			expectedCommands.Enqueue(expectedCommand);
		}

		public int ExecuteNonQuery(IDbCommand command)
		{
			return GetExpectedCommand(command, DummyCommandType.NonQuery).NonQueryResult;
		}

		public object ExecuteScalar(IDbCommand command)
		{
			return GetExpectedCommand(command, DummyCommandType.Scalar).ScalarResult;
		}

		public DbDataReader ExecuteReader(IDbCommand command)
		{
			return new DummyDataReader(GetExpectedCommand(command, DummyCommandType.Reader).ReaderResult);
		}

		public void DeriveParameters(IDbCommand command)
		{
			foreach (object parameter in GetExpectedCommandWithoutParameters(command, DummyCommandType.DeriveParameters).Parameters)
			{
				command.Parameters.Add(parameter);
			}
		}

		private DummyCommand GetExpectedCommand(IDbCommand command, DummyCommandType commandType)
		{
			DummyCommand expectedCommand = GetExpectedCommandWithoutParameters(command, commandType);
			Assert.That(command.Parameters.Count, Is.EqualTo(expectedCommand.Parameters.Count));
			for (int index = 0; index < command.Parameters.Count; index++)
			{
				var parameter = (IDataParameter)command.Parameters[index];
				var expectedParameter = expectedCommand.Parameters[index];
				Assert.That(parameter.ParameterName, Is.EqualTo(expectedParameter.ParameterName));
				if (expectedParameter.Direction == ParameterDirection.Input)
				{
					if (parameter.Value is DateTime)
					{
						var parameterValue = (DateTime)parameter.Value;
						if (parameterValue.Hour != 0 || parameterValue.Minute != 0 || parameterValue.Second != 0 || parameterValue.Millisecond != 0)
						{
							continue;
						}
					}
					
					Assert.That(parameter.Value, Is.EqualTo(expectedParameter.Value));
				}
				else
				{
					parameter.Value = expectedParameter.Value;
				}
			}

			return expectedCommand;
		}

		private DummyCommand GetExpectedCommandWithoutParameters(IDbCommand command, DummyCommandType commandType)
		{
			DummyCommand expectedCommand = expectedCommands.Dequeue();
			Assert.That(expectedCommand.DummyCommandType, Is.EqualTo(commandType));
			Assert.That(command.CommandText, Is.EqualTo(expectedCommand.CommandText));
			return expectedCommand;
		}
	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ax.UnitTests.IntegrationTestRunners
{
	internal sealed class DummyDataReaderBuilder : AbstractDummyDataReader<DummyDataReaderBuilderResult>
	{
		private readonly IIndexedEnumerator<DummyDataReaderBuilderResult> results;

		public DummyDataReaderBuilder(ICollection<DummyDataReaderResultBuilder> results)
			: this(results.Select(result => new DummyDataReaderBuilderResult(result.Rows, result.FieldNames)), results.Count)
		{
		}

		private DummyDataReaderBuilder(IEnumerable<DummyDataReaderBuilderResult> results, int length)
			: this(new IndexedEnumerator<DummyDataReaderBuilderResult>(results.GetEnumerator(), length))
		{
		}

		private DummyDataReaderBuilder(IIndexedEnumerator<DummyDataReaderBuilderResult> results)
			: base(results)
		{
			this.results = results;
		}

		public override int FieldCount
		{
			get { return results.Current.FieldNames.Length; }
		}

		public override Type GetFieldType(int ordinal)
		{
			return null;
		}

		public override string GetName(int ordinal)
		{
			return results.Current.FieldNames[ordinal];
		}

		public override int GetOrdinal(string name)
		{
			return Array.IndexOf(results.Current.FieldNames, name);
		}

		public override object GetValue(int ordinal)
		{
			return results.Current.Current[ordinal];
		}
	}
}
